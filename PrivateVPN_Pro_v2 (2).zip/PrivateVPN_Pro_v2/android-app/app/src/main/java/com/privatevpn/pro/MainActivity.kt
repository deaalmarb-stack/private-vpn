package com.privatevpn.pro

import android.app.Activity
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.StringReader

class MainActivity : AppCompatActivity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var backend: GoBackend
    private lateinit var securePrefs: SharedPreferences
    private lateinit var tvStatus: TextView
    private lateinit var tvTraffic: TextView
    private lateinit var tvLog: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnImport: Button
    private lateinit var spinnerDns: Spinner
    private lateinit var etConfig: EditText

    private var isConnected = false
    private var statsJob: Job? = null
    private val keyConfig = "wg_encrypted_config"

    private val dnsOptions = listOf(
        "Cloudflare (1.1.1.1, 1.0.0.1)",
        "Quad9 (9.9.9.9, 149.112.112.112)",
        "Google (8.8.8.8, 8.8.4.4)"
    )
    private val dnsValues = listOf(
        "1.1.1.1, 1.0.0.1",
        "9.9.9.9, 149.112.112.112",
        "8.8.8.8, 8.8.4.4"
    )

    private val tunnel = object : Tunnel {
        override fun getName(): String = "PrivateVPNPro"
        override fun onStateChange(newState: Tunnel.State) {
            runOnUiThread {
                updateUiState(newState == Tunnel.State.UP)
            }
        }
    }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            connectTunnel()
        } else {
            Toast.makeText(this, "يجب منح صلاحية VPN للاتصال", Toast.LENGTH_SHORT).show()
        }
    }

    private val importConfigLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    val text = BufferedReader(InputStreamReader(stream)).readText()
                    etConfig.setText(text)
                    saveEncryptedConfig(text)
                    tvLog.text = "تم استيراد وحفظ الإعدادات بشكل مشفّر."
                }
            } catch (e: Exception) {
                tvLog.text = "خطأ في قراءة الملف: ${e.message}"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        backend = GoBackend(applicationContext)
        securePrefs = initSecurePrefs()

        tvStatus = findViewById(R.id.tvStatus)
        tvTraffic = findViewById(R.id.tvTraffic)
        tvLog = findViewById(R.id.tvLog)
        btnToggle = findViewById(R.id.btnToggle)
        btnImport = findViewById(R.id.btnImport)
        spinnerDns = findViewById(R.id.spinnerDns)
        etConfig = findViewById(R.id.etConfig)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, dnsOptions)
        spinnerDns.adapter = adapter

        val saved = securePrefs.getString(keyConfig, "")
        if (!saved.isNullOrBlank()) {
            etConfig.setText(saved)
        }

        btnImport.setOnClickListener {
            importConfigLauncher.launch(arrayOf("*/*"))
        }

        btnToggle.setOnClickListener {
            if (isConnected) {
                disconnectTunnel()
            } else {
                val intent = GoBackend.VpnService.prepare(this)
                if (intent != null) {
                    vpnPermissionLauncher.launch(intent)
                } else {
                    connectTunnel()
                }
            }
        }
    }

    private fun initSecurePrefs(): SharedPreferences {
        val masterKey = MasterKey.Builder(applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            applicationContext,
            "private_vpn_pro_vault",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private fun applySelectedDns(raw: String): String {
        val chosenDns = dnsValues[spinnerDns.selectedItemPosition]
        return if (Regex("(?i)^DNS\s*=.*$", RegexOption.MULTILINE).containsMatchIn(raw)) {
            raw.replace(Regex("(?i)^DNS\s*=.*$", RegexOption.MULTILINE), "DNS = $chosenDns")
        } else {
            raw.replace("[Interface]", "[Interface]
DNS = $chosenDns")
        }
    }

    private fun connectTunnel() {
        val rawInput = etConfig.text.toString().trim()
        if (rawInput.isEmpty()) {
            Toast.makeText(this, "يرجى إدخال أو استيراد ملف إعدادات client1.conf أولًا", Toast.LENGTH_LONG).show()
            return
        }
        val finalConfig = applySelectedDns(rawInput)
        saveEncryptedConfig(finalConfig)
        tvStatus.text = getString(R.string.status_connecting)
        btnToggle.isEnabled = false

        scope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    Config.parse(BufferedReader(StringReader(finalConfig)))
                }
                withContext(Dispatchers.IO) {
                    backend.setState(tunnel, Tunnel.State.UP, parsed)
                }
                tvLog.text = "النفق المشفّر نشط مع DNS مقاوم للحجب."
                startStatsPolling()
            } catch (e: Exception) {
                updateUiState(false)
                tvLog.text = "فشل الاتصال: ${e.message}"
            } finally {
                btnToggle.isEnabled = true
            }
        }
    }

    private fun disconnectTunnel() {
        btnToggle.isEnabled = false
        statsJob?.cancel()
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                }
                tvTraffic.text = "التنزيل: 0 KB  |  الرفع: 0 KB"
                tvLog.text = "تم قطع الاتصال بأمان."
            } catch (e: Exception) {
                tvLog.text = "خطأ أثناء قطع الاتصال: ${e.message}"
            } finally {
                btnToggle.isEnabled = true
            }
        }
    }

    private fun startStatsPolling() {
        statsJob?.cancel()
        statsJob = scope.launch {
            while (isActive && isConnected) {
                try {
                    val stats = withContext(Dispatchers.IO) { backend.getStatistics(tunnel) }
                    val rxKb = stats.totalRx() / 1024
                    val txKb = stats.totalTx() / 1024
                    tvTraffic.text = "التنزيل: $rxKb KB  |  الرفع: $txKb KB"
                } catch (_: Exception) {
                }
                delay(1500)
            }
        }
    }

    private fun updateUiState(connected: Boolean) {
        isConnected = connected
        if (connected) {
            tvStatus.text = getString(R.string.status_connected)
            tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_green))
            btnToggle.text = getString(R.string.btn_disconnect)
        } else {
            statsJob?.cancel()
            tvStatus.text = getString(R.string.status_disconnected)
            tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_red))
            btnToggle.text = getString(R.string.btn_connect)
        }
    }

    private fun saveEncryptedConfig(text: String) {
        securePrefs.edit().putString(keyConfig, text).apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}

#!/usr/bin/env bash
set -euo pipefail

# PrivateVPN Pro v2 — High-Speed WireGuard + BBR Congestion Control Setup (Ubuntu / Debian)
# Usage: sudo ./setup_vpn_server.sh

if [[ $EUID -ne 0 ]]; then
  echo "يرجى تشغيل السكربت بصلاحيات root باستخدام: sudo ./setup_vpn_server.sh"
  exit 1
fi

WG_PORT="${WG_PORT:-51820}"
WG_INTERFACE="wg0"
SERVER_NET_IPV4="10.66.66.1/24"
CLIENT_IP_IPV4="10.66.66.2/32"
CLIENT_DNS="${CLIENT_DNS:-1.1.1.1, 9.9.9.9}"

echo "[1/7] تحديث النظام وتثبيت WireGuard و qrencode..."
apt-get update -y
apt-get install -y wireguard qrencode iptables curl ca-certificates

echo "[2/7] تفعيل خوارزمية TCP BBR لتسريع الاتصال وتقليل التقطيع..."
cat > /etc/sysctl.d/99-privatevpn-pro.conf <<EOF
net.ipv4.ip_forward = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
EOF
sysctl --system >/dev/null

echo "[3/7] اكتشاف واجهة الشبكة وعنوان IP العام..."
DEFAULT_NIC=$(ip route get 1.1.1.1 | awk '{for(i=1;i<=NF;i++) if ($i=="dev") print $(i+1)}' | head -n1)
PUBLIC_IP=$(curl -4 -s https://api.ipify.org || curl -4 -s https://ifconfig.me)

if [[ -z "$DEFAULT_NIC" || -z "$PUBLIC_IP" ]]; then
  echo "تعذر اكتشاف واجهة الشبكة أو عنوان IP العام."
  exit 1
fi

echo "[4/7] توليد مفاتيح التشفير (Curve25519 + PresharedKey)..."
umask 077
mkdir -p /etc/wireguard
SERVER_PRIV=$(wg genkey)
SERVER_PUB=$(echo "$SERVER_PRIV" | wg pubkey)
CLIENT_PRIV=$(wg genkey)
CLIENT_PUB=$(echo "$CLIENT_PRIV" | wg pubkey)
PRESHARED_KEY=$(wg genpsk)

echo "[5/7] كتابة إعدادات الخادم /etc/wireguard/${WG_INTERFACE}.conf..."
cat > "/etc/wireguard/${WG_INTERFACE}.conf" <<EOF
[Interface]
Address = ${SERVER_NET_IPV4}
ListenPort = ${WG_PORT}
PrivateKey = ${SERVER_PRIV}
MTU = 1280
PostUp = iptables -A FORWARD -i ${WG_INTERFACE} -j ACCEPT; iptables -A FORWARD -o ${WG_INTERFACE} -j ACCEPT; iptables -t nat -A POSTROUTING -o ${DEFAULT_NIC} -j MASQUERADE
PostDown = iptables -D FORWARD -i ${WG_INTERFACE} -j ACCEPT; iptables -D FORWARD -o ${WG_INTERFACE} -j ACCEPT; iptables -t nat -D POSTROUTING -o ${DEFAULT_NIC} -j MASQUERADE

[Peer]
PublicKey = ${CLIENT_PUB}
PresharedKey = ${PRESHARED_KEY}
AllowedIPs = ${CLIENT_IP_IPV4}
EOF

echo "[6/7] فتح المنفذ وتفعيل الخدمة تلقائيًا عند إعادة التشغيل..."
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow "${WG_PORT}/udp"
fi
systemctl enable "wg-quick@${WG_INTERFACE}"
systemctl restart "wg-quick@${WG_INTERFACE}"

echo "[7/7] إنشاء ملف العميل /root/client1.conf مع PersistentKeepalive..."
cat > /root/client1.conf <<EOF
[Interface]
PrivateKey = ${CLIENT_PRIV}
Address = ${CLIENT_IP_IPV4}
DNS = ${CLIENT_DNS}
MTU = 1280

[Peer]
PublicKey = ${SERVER_PUB}
PresharedKey = ${PRESHARED_KEY}
Endpoint = ${PUBLIC_IP}:${WG_PORT}
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
EOF

chmod 600 /root/client1.conf
echo "تم الإعداد بنجاح! ملف الإعدادات: /root/client1.conf"
qrencode -t ansiutf8 < /root/client1.conf

#!/usr/bin/env bash
set -euo pipefail

# PrivateVPN Pro v2 — Anti-DPI VLESS + XTLS-Reality (Xray-core) Setup Script
# Disguises VPN traffic as standard TLS 1.3 HTTPS to bypass deep packet inspection.
# Usage: sudo ./setup_vless_reality.sh

if [[ $EUID -ne 0 ]]; then
  echo "يرجى تشغيل السكربت بصلاحيات root باستخدام: sudo ./setup_vless_reality.sh"
  exit 1
fi

SNI_DOMAIN="${SNI_DOMAIN:-www.cloudflare.com}"
LISTEN_PORT="${LISTEN_PORT:-443}"

echo "[1/5] تثبيت المتطلبات وتنزيل Xray-core..."
apt-get update -y
apt-get install -y curl unzip openssl qrencode
bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install

echo "[2/5] توليد مفاتيح X25519 ومعرّف UUID..."
UUID=$(xray uuid)
KEYS=$(xray x25519)
PRIVATE_KEY=$(echo "$KEYS" | awk '/Private key:/ {print $3}')
PUBLIC_KEY=$(echo "$KEYS" | awk '/Public key:/ {print $3}')
SHORT_ID=$(openssl rand -hex 8)
PUBLIC_IP=$(curl -4 -s https://api.ipify.org || curl -4 -s https://ifconfig.me)

echo "[3/5] كتابة إعدادات الخادم /usr/local/etc/xray/config.json..."
cat > /usr/local/etc/xray/config.json <<EOF
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "listen": "0.0.0.0",
      "port": ${LISTEN_PORT},
      "protocol": "vless",
      "settings": {
        "clients": [
          { "id": "${UUID}", "flow": "xtls-rprx-vision" }
        ],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "dest": "${SNI_DOMAIN}:443",
          "xver": 0,
          "serverNames": ["${SNI_DOMAIN}"],
          "privateKey": "${PRIVATE_KEY}",
          "shortIds": ["${SHORT_ID}"]
        }
      }
    }
  ],
  "outbounds": [
    { "protocol": "freedom", "tag": "direct" }
  ]
}
EOF

echo "[4/5] تفعيل الخدمة وفتح المنفذ ${LISTEN_PORT}/tcp..."
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow "${LISTEN_PORT}/tcp"
fi
systemctl enable xray
systemctl restart xray

echo "[5/5] توليد رابط الاتصال VLESS-Reality..."
VLESS_LINK="vless://${UUID}@${PUBLIC_IP}:${LISTEN_PORT}?encryption=none&flow=xtls-rprx-vision&security=reality&sni=${SNI_DOMAIN}&fp=chrome&pbk=${PUBLIC_KEY}&sid=${SHORT_ID}&type=tcp#PrivateVPN-Reality"
echo "$VLESS_LINK" > /root/vless_reality_link.txt
chmod 600 /root/vless_reality_link.txt

echo ""
echo "========================================================"
echo "تم إعداد خادم VLESS-Reality بنجاح!"
echo "رابط الاتصال محفوظ في: /root/vless_reality_link.txt"
echo "$VLESS_LINK"
echo "========================================================"
qrencode -t ansiutf8 "$VLESS_LINK"

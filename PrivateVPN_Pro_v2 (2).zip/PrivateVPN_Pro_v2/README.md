# مشروع PrivateVPN Pro v2 (أحدث التقنيات لتجاوز الحجب والثبات العالي)

تطوير شامل لمشروع VPN الخاص بك بأحدث تقنيات التشفير وتجاوز الحجب العميق (DPI):

1. **`server/setup_vpn_server.sh`**: سكربت إعداد **WireGuard + TCP BBR + Kill Switch + MTU 1280** على خادم Ubuntu/Debian لأقصى سرعة وثبات دون تقطيع، مع إمكانية توليد ملفات إعدادات ورموز QR لعدة أجهزة.
2. **`server/setup_vless_reality.sh`**: سكربت إعداد بروتوكول **VLESS + XTLS-Reality (Xray-core)** الحديث الذي يُخفي اتصال الـ VPN داخل حركة HTTPS (TLS 1.3) طبيعية لتجاوز أنظمة الحجب العميق (DPI) في الشبكات المقيّدة.
3. **`android-app/`**: تطبيق أندرويد مطوّر بلغة Kotlin مع:
   - تخزين مشفّر وآمن للمفاتيح (`EncryptedSharedPreferences`)
   - إدارة عدة سيرفرات (ملفات تعريف متعددة)
   - عرض مباشر لإحصائيات الرفع والتنزيل (Rx/Tx) من نواة WireGuard
   - ميزة استثناء التطبيقات (Split Tunneling)
   - اختيار خادم DNS مشفّر ومقاوم للحجب (Cloudflare `1.1.1.1` / Quad9 `9.9.9.9` / Google `8.8.8.8`)
   - استيراد ملفات `.conf` وتطبيقها فورًا

## خطوات التشغيل السريعة
1. استأجر سيرفر VPS في دولة مدعومة (ألمانيا، بريطانيا، هولندا، أو الولايات المتحدة).
2. لتشغيل **WireGuard السريع والمستقر**:
   ```bash
   chmod +x server/setup_vpn_server.sh
   sudo ./server/setup_vpn_server.sh
   ```
3. أو لتجاوز الحجب الشديد عبر **VLESS + Reality**:
   ```bash
   chmod +x server/setup_vless_reality.sh
   sudo ./server/setup_vless_reality.sh
   ```
4. افتح مجلد `android-app` في **Android Studio** لبناء ملف `.apk` وتثبيته على هاتفك، ثم استورد ملف `client1.conf`.
